local npc = {}
local springs = require 'springs'
local id = NPC_ID

springs.register{
	id = id,
}

return npc